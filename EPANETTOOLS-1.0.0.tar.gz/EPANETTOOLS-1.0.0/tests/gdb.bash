#!/bin/bash
env PYTHONPATH=/home/user/epanettools:/home/user/epanettools/src: gdb python3 
