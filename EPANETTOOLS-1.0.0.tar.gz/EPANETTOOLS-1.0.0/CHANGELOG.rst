
Changelog
=========
1.0.0 (2018-09-28)
-----------------------------------------
* Now works with python > 3.4. 
* Uses visual c/c++ compilers for windows

.9.0 (2016-11-13)
-----------------------------------------
* Available demand fraction with pipes closed added. This was done with c library for efficiency.


0.8.0 (2016-10-06)
-----------------------------------------
* completely removed dependency on numpy.  

0.7.2 (2016-09-28)
-----------------------------------------
* bug fixes

0.7.1 (2016-09-21)
-----------------------------------------
* minor changes

0.7.0 (2016-09-21)
-----------------------------------------

* A substantial upgrade from version 6.x 
* Added pressure-driven demand
* Restuructured repo-structure completely
* much better testing with CI
