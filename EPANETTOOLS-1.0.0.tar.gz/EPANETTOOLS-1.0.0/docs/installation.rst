============
Installation
============

At the command line::

    pip install epanettools
