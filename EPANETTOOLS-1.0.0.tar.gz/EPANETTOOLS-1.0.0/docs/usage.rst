=====
Usage
=====

To use epanettools in a project::

	import epanettools
