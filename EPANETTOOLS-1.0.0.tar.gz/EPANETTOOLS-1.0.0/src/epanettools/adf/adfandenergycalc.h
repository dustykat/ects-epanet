#ifndef ADFCALC_H
#define  ADFCALC_H

void ADF_calculation(char* inpfile, char* outfile, float diafact);

#endif
